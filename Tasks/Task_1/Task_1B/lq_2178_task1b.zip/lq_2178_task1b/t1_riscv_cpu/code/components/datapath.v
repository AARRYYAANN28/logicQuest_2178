// datapath.v
module datapath (
    input         clk, reset,
    input [1:0]   ResultSrc,
    input         PCSrc, ALUSrc,
    input         RegWrite,
    input [2:0]   ImmSrc,
    input [2:0]   ALUControl,
    input         ALUSrcA,
    input         JALR,
    output        Zero,
    output [31:0] PC,
    input  [31:0] Instr,
    output [31:0] Mem_WrAddr, Mem_WrData,
    input  [31:0] ReadData,
    output [31:0] Result
);

wire [31:0] PCNext, PCPlus4, PCTargetBase, PCTarget;
wire [31:0] ImmExt, SrcA, SrcASelected, SrcB, WriteData, ALUResult;

// next PC logic
reset_ff #(32) pcreg(clk, reset, PCNext, PC);
adder          pcadd4(PC, 32'd4, PCPlus4);
adder          pcaddbranch(PC, ImmExt, PCTargetBase);

// JAL uses PC + immediate.
// JALR uses rs1 + immediate, which is ALUResult.
mux2 #(32)     jaltargetmux(PCTargetBase, ALUResult, JALR, PCTarget);
mux2 #(32)     pcmux(PCPlus4, PCTarget, PCSrc, PCNext);

// register file logic
reg_file       rf (clk, RegWrite, Instr[19:15], Instr[24:20],
                   Instr[11:7], Result, SrcA, WriteData);
imm_extend     ext (Instr[31:7], ImmSrc, ImmExt);

// ALU first operand:
// normal instructions use rs1; AUIPC uses the current PC.
mux2 #(32)     srcamux(SrcA, PC, ALUSrcA, SrcASelected);

// ALU logic
mux2 #(32)     srcbmux(WriteData, ImmExt, ALUSrc, SrcB);
alu             alu (SrcASelected, SrcB, ALUControl, ALUResult, Zero);

// ResultSrc:
// 00 = ALU result
// 01 = data memory
// 10 = PC + 4 (used by JAL/JALR)
mux3 #(32)     resultmux(ALUResult, ReadData, PCPlus4, ResultSrc, Result);

assign Mem_WrData = WriteData;
assign Mem_WrAddr = ALUResult;

endmodule
