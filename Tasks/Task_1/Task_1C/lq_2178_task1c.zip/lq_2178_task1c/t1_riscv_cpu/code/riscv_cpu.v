/*
# Team ID:          2178
# Theme:            Logic Quest
# Author List:      ARYAN GUPTA, SAUJAN PANJA, ADITYA SINGH, MANJEET CHITODIYA
# Filename:         riscv_cpu.v
# File Description: Top-level single-cycle RV32I CPU core.
# Global variables: None
*/

module riscv_cpu (
    input         clk, reset,
    output [31:0] PC,
    input  [31:0] Instr,
    output        MemWrite,
    output [31:0] Mem_WrAddr, Mem_WrData, Mem_WrDataMem,
    input  [31:0] ReadData,
    output [31:0] Result
);

wire        ALUSrc, RegWrite, Jump, Zero, BranchTaken;
wire        ALUSrcA, JALR;
wire [1:0]  ResultSrc;
wire [2:0]  ImmSrc, BranchType;
wire [1:0]  MemSize;
wire        LoadUnsigned;
wire [3:0]  ALUControl;
wire        PCSrc;

controller c (
    Instr[6:0], Instr[14:12], Instr[30], BranchTaken,
    ResultSrc, MemWrite, PCSrc, ALUSrc, RegWrite, Jump,
    ImmSrc, ALUControl, ALUSrcA, JALR,
    BranchType, MemSize, LoadUnsigned
);

datapath dp (
    clk, reset, ResultSrc, PCSrc,
    ALUSrc, RegWrite, ImmSrc, ALUControl,
    ALUSrcA, JALR, BranchType, MemSize, LoadUnsigned,
    BranchTaken, Zero, PC, Instr,
    Mem_WrAddr, Mem_WrData, Mem_WrDataMem,
    ReadData, Result
);

endmodule
