// instr_mem.v - instruction memory

module instr_mem #(parameter DATA_WIDTH = 32, ADDR_WIDTH = 32, MEM_SIZE = 512) (
    input  [ADDR_WIDTH-1:0] instr_addr,
    output [DATA_WIDTH-1:0] instr
);

// Instruction memory contains the program used by the active task testbench.
reg [DATA_WIDTH-1:0] instr_ram [0:MEM_SIZE-1];

initial begin
    // $readmemh("rv32i_book.hex", instr_ram);
    // $readmemh("rv32i_test_1b.hex", instr_ram);
    $readmemh("rv32i_test_1c.hex", instr_ram);
end

// Word-aligned combinational instruction fetch.
assign instr = instr_ram[instr_addr[31:2]];

endmodule
