/*
# Team ID:          2178
# Theme:            Logic Quest
# Author List:      ARYAN GUPTA, SAUJAN PANJA, ADITYA SINGH, MANJEET CHITODIYA
# Filename:         datapath.v
# File Description: Implements the CPU datapath, branch comparison, and sub-word memory access.
# Global variables: None
*/

module datapath (
    input         clk, reset,
    input [1:0]   ResultSrc,
    input         PCSrc, ALUSrc,
    input         RegWrite,
    input [2:0]   ImmSrc,
    input [3:0]   ALUControl,
    input         ALUSrcA,
    input         JALR,
    input [2:0]   BranchType,
    input [1:0]   MemSize,
    input         LoadUnsigned,
    output reg    BranchTaken,
    output        Zero,
    output [31:0] PC,
    input  [31:0] Instr,
    output [31:0] Mem_WrAddr, Mem_WrData, Mem_WrDataMem,
    input  [31:0] ReadData,
    output [31:0] Result
);

wire [31:0] PCNext, PCPlus4, PCTargetBase, PCTarget;
wire [31:0] ImmExt, SrcA, SrcASelected, SrcB, WriteData, ALUResult;
reg  [31:0] LoadResult;
reg  [31:0] StoreMergedData;
reg  [31:0] LoadByteHalf;

// Program-counter logic.
reset_ff #(32) pcreg(clk, reset, PCNext, PC);
adder          pcadd4(PC, 32'd4, PCPlus4);
adder          pcaddbranch(PC, ImmExt, PCTargetBase);

// JAL uses PC+imm; JALR uses rs1+imm and clears bit 0 as required by RV32I.
assign PCTarget = JALR ? {ALUResult[31:1], 1'b0} : PCTargetBase;
mux2 #(32) pcmux(PCPlus4, PCTarget, PCSrc, PCNext);

// Register-file read/write logic.
reg_file rf (clk, RegWrite, Instr[19:15], Instr[24:20],
             Instr[11:7], Result, SrcA, WriteData);
imm_extend ext (Instr[31:7], ImmSrc, ImmExt);

// AUIPC selects the current PC as the ALU's first operand.
mux2 #(32) srcamux(SrcA, PC, ALUSrcA, SrcASelected);
mux2 #(32) srcbmux(WriteData, ImmExt, ALUSrc, SrcB);

alu alu (SrcASelected, SrcB, ALUControl, ALUResult, Zero);

/*
 * Purpose:
 * Evaluate all six RV32I conditional branch predicates directly from the
 * two register operands. Signed branches use $signed; unsigned branches
 * use the normal unsigned comparison.
 */
always @(*) begin
    case (BranchType)
        3'b001: BranchTaken = (SrcA == WriteData);                    // BEQ
        3'b010: BranchTaken = (SrcA != WriteData);                    // BNE
        3'b011: BranchTaken = ($signed(SrcA) <  $signed(WriteData));  // BLT
        3'b100: BranchTaken = ($signed(SrcA) >= $signed(WriteData));  // BGE
        3'b101: BranchTaken = (SrcA < WriteData);                     // BLTU
        3'b110: BranchTaken = (SrcA >= WriteData);                    // BGEU
        default: BranchTaken = 1'b0;
    endcase
end

/*
 * Purpose:
 * Extract the addressed byte/half-word from the 32-bit memory word and
 * apply sign or zero extension for LB/LH/LBU/LHU. LW bypasses this logic.
 */
always @(*) begin
    case (MemSize)
        2'b01: begin // byte
            case (ALUResult[1:0])
                2'd0: LoadByteHalf = {24'b0, ReadData[7:0]};
                2'd1: LoadByteHalf = {24'b0, ReadData[15:8]};
                2'd2: LoadByteHalf = {24'b0, ReadData[23:16]};
                default: LoadByteHalf = {24'b0, ReadData[31:24]};
            endcase
            if (!LoadUnsigned && LoadByteHalf[7])
                LoadResult = {{24{1'b1}}, LoadByteHalf[7:0]};
            else
                LoadResult = LoadByteHalf;
        end

        2'b10: begin // half-word
            if (ALUResult[1])
                LoadByteHalf = {16'b0, ReadData[31:16]};
            else
                LoadByteHalf = {16'b0, ReadData[15:0]};

            if (!LoadUnsigned && LoadByteHalf[15])
                LoadResult = {{16{1'b1}}, LoadByteHalf[15:0]};
            else
                LoadResult = LoadByteHalf;
        end

        default: begin // word
            LoadResult = ReadData;
            LoadByteHalf = ReadData;
        end
    endcase
end

/*
 * Purpose:
 * Build the full 32-bit word written to the word-addressed data memory for
 * SB/SH/SW. The external CPU-facing WriteData remains the original rs2
 * value, while Mem_WrDataMem performs the required read-modify-write.
 */
always @(*) begin
    StoreMergedData = WriteData;

    case (MemSize)
        2'b01: begin // SB
            case (ALUResult[1:0])
                2'd0: StoreMergedData = {ReadData[31:8],  WriteData[7:0]};
                2'd1: StoreMergedData = {ReadData[31:16], WriteData[7:0], ReadData[7:0]};
                2'd2: StoreMergedData = {ReadData[31:24], WriteData[7:0], ReadData[15:0]};
                default: StoreMergedData = {WriteData[7:0], ReadData[23:0]};
            endcase
        end
        2'b10: begin // SH
            if (ALUResult[1])
                StoreMergedData = {WriteData[15:0], ReadData[15:0]};
            else
                StoreMergedData = {ReadData[31:16], WriteData[15:0]};
        end
        default: StoreMergedData = WriteData; // SW
    endcase
end

// Result returned to the register file/debug output.
mux3 #(32) resultmux(ALUResult, LoadResult, PCPlus4, ResultSrc, Result);

assign Mem_WrAddr    = ALUResult;
assign Mem_WrData    = WriteData;
assign Mem_WrDataMem = StoreMergedData;

endmodule
