/*
# Team ID:          2178
# Theme:            Logic Quest
# Author List:      ARYAN GUPTA, SAUJAN PANJA, ADITYA SINGH, MANJEET CHITODIYA
# Filename:         controller.v
# File Description: Combines main and ALU decoding and generates branch/memory controls.
# Global variables: None
*/

module controller (
    input  [6:0] op,
    input  [2:0] funct3,
    input        funct7b5,
    input        BranchTaken,
    output [1:0] ResultSrc,
    output       MemWrite,
    output       PCSrc, ALUSrc,
    output       RegWrite, Jump,
    output [2:0] ImmSrc,
    output [3:0] ALUControl,
    output       ALUSrcA,
    output       JALR,
    output reg [2:0] BranchType,
    output reg [1:0] MemSize,
    output reg       LoadUnsigned
);

wire [1:0] ALUOp;
wire       Branch;

main_decoder md (
    op, ResultSrc, MemWrite, Branch,
    ALUSrc, RegWrite, Jump, ImmSrc, ALUOp,
    ALUSrcA, JALR
);

alu_decoder ad (
    op[5], funct3, funct7b5, ALUOp, ALUControl
);

always @(*) begin
    /* Purpose: Decode branch condition and memory access width from funct3. */
    BranchType   = 3'b000;
    MemSize      = 2'b00;
    LoadUnsigned = 1'b0;

    if (op == 7'b1100011) begin
        case (funct3)
            3'b000: BranchType = 3'b001; // BEQ
            3'b001: BranchType = 3'b010; // BNE
            3'b100: BranchType = 3'b011; // BLT
            3'b101: BranchType = 3'b100; // BGE
            3'b110: BranchType = 3'b101; // BLTU
            3'b111: BranchType = 3'b110; // BGEU
            default: BranchType = 3'b000;
        endcase
    end

    if (op == 7'b0000011 || op == 7'b0100011) begin
        case (funct3)
            3'b000: MemSize = 2'b01; // byte
            3'b001: MemSize = 2'b10; // half-word
            3'b010: MemSize = 2'b00; // word
            3'b100: begin MemSize = 2'b01; LoadUnsigned = 1'b1; end // LBU
            3'b101: begin MemSize = 2'b10; LoadUnsigned = 1'b1; end // LHU
            default: begin MemSize = 2'b00; LoadUnsigned = 1'b0; end
        endcase
    end
end

assign PCSrc = Jump | (Branch & BranchTaken);

endmodule
