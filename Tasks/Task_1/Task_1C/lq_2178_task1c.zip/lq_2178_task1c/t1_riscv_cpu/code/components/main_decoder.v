/*
# Team ID:          2178
# Theme:            Logic Quest
# Author List:      ARYAN GUPTA, SAUJAN PANJA, ADITYA SINGH, MANJEET CHITODIYA
# Filename:         main_decoder.v
# File Description: Decodes the instruction opcode into CPU control signals.
# Global variables: None
*/

module main_decoder (
    input  [6:0] op,
    output reg [1:0] ResultSrc,
    output reg       MemWrite, Branch, ALUSrc,
    output reg       RegWrite, Jump,
    output reg [2:0] ImmSrc,
    output reg [1:0] ALUOp,
    output reg       ALUSrcA,
    output reg       JALR
);

always @(*) begin
    /* Purpose: Decode the opcode into the high-level CPU control signals. */
    ResultSrc = 2'b00;
    MemWrite  = 1'b0;
    Branch    = 1'b0;
    ALUSrc    = 1'b0;
    RegWrite  = 1'b0;
    Jump      = 1'b0;
    ImmSrc    = 3'b000;
    ALUOp     = 2'b00;
    ALUSrcA   = 1'b0;
    JALR      = 1'b0;

    case (op)
        7'b0000011: begin // LB/LH/LW/LBU/LHU
            RegWrite  = 1'b1;
            ALUSrc    = 1'b1;
            ImmSrc    = 3'b000;
            ResultSrc = 2'b01;
        end
        7'b0100011: begin // SB/SH/SW
            ALUSrc   = 1'b1;
            ImmSrc   = 3'b001;
            MemWrite = 1'b1;
        end
        7'b0110011: begin // R-type ALU
            RegWrite = 1'b1;
            ALUOp    = 2'b10;
        end
        7'b1100011: begin // BEQ/BNE/BLT/BGE/BLTU/BGEU
            ImmSrc = 3'b010;
            Branch = 1'b1;
            ALUOp  = 2'b01;
        end
        7'b0010011: begin // ADDI/SLLI/SLTI/SLTIU/XORI/SRLI/SRAI/ORI/ANDI
            RegWrite = 1'b1;
            ALUSrc   = 1'b1;
            ImmSrc   = 3'b000;
            ALUOp    = 2'b10;
        end
        7'b1101111: begin // JAL
            RegWrite  = 1'b1;
            ImmSrc    = 3'b011;
            ResultSrc = 2'b10;
            Jump      = 1'b1;
        end
        7'b0110111: begin // LUI
            RegWrite = 1'b1;
            ImmSrc   = 3'b100;
            ALUSrc   = 1'b1;
        end
        7'b0010111: begin // AUIPC
            RegWrite = 1'b1;
            ImmSrc   = 3'b100;
            ALUSrc   = 1'b1;
            ALUSrcA  = 1'b1;
        end
        7'b1100111: begin // JALR
            RegWrite  = 1'b1;
            ImmSrc    = 3'b000;
            ALUSrc    = 1'b1;
            ResultSrc = 2'b10;
            Jump      = 1'b1;
            JALR      = 1'b1;
        end
        default: begin
            // Safe inactive defaults above.
        end
    endcase
end

endmodule
